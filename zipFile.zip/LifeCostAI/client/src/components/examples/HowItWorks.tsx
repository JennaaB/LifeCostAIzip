import HowItWorks from '../HowItWorks';

export default function HowItWorksExample() {
  return <HowItWorks />;
}
