import LoadingDashboard from '../LoadingDashboard';

export default function LoadingDashboardExample() {
  return <LoadingDashboard />;
}
