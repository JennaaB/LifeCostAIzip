import GlobalMap from '../GlobalMap';

export default function GlobalMapExample() {
  return <GlobalMap baseAmount={2847} baseCity="Calgary" />;
}
