import PrivacyPromise from '../PrivacyPromise';

export default function PrivacyPromiseExample() {
  return <PrivacyPromise />;
}
